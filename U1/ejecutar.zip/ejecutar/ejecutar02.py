print("Bienvenido a PEP")
print ("Espero que el programa se ejecute correctamente")
nombre=input(" ¿Cómo te llamas? ")
print(" Bienvenido ", nombre," !!")