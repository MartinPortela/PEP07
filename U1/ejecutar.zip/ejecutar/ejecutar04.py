print("Bienvenido a PEP")

print("Espero que el programa se ejecute correctamente")


nombre = input(" ¿Cómo te llamas? ")
  print(" Bienvenido ", nombre, " !!")

edad = int(input(" ¿Cuantos años tienes? "))
if edad > 18
print("Eres mayor de edad")
else:
    print("Eres menor de edad")
print("Adios!")
